﻿namespace SeleniumExtras
{
    internal class WaitHelpers
    {
        public static object ExpectedConditions { get; internal set; }
    }
}