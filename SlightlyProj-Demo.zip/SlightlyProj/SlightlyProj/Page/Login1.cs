﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading.Tasks;
using System.Threading;

namespace SlightlyProj.Page
{
    public class Login1 :PageUtil.PageBase
    {
        //private Logger logger = LogManager.GetCurrentClassLogger();
        private IWebDriver driver=null;

        public Login1(IWebDriver passed_driver)
        : base(passed_driver)
    {
        try
        {
            driver = passed_driver;

            if (!driver.Url.Contains("sightly"))
                throw new NoSuchWindowException("This is not the login page");

            Thread.Sleep(100);
            //PageFactory.InitElements(driver, this);
            Thread.Sleep(100);
                
        }
        catch (Exception ex)
        {
            //logger.Error(ex, "Diagnostic Message");
        }
    }
    
     

        
        IWebElement inputUserName => driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div/div/div[1]/div[2]/div[3]/input[@type='text']"));
        IWebElement inputPassword => driver.FindElement(By.XPath("//input[@type='password']"));
        IWebElement buttonClick => driver.FindElement(By.XPath("//button[@class='login-button']"));

        

        public void login(string username, string password)
        {
            inputUserName.SendKeys(username);
            Thread.Sleep(10);
            inputPassword.SendKeys(password);
            Thread.Sleep(10);
            buttonClick.Click();
            Thread.Sleep(10);
        }
    }
}
