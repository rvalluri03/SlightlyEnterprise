﻿using System;

namespace SlightlyProj
{
    public class Class1
    {
    }
}
