﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using NLog;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using OfficeOpenXml;
using System.IO;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using OfficeOpenXml.Style;
using Microsoft.Office.Interop.Excel;


namespace SlightlyProj.PageUtil
{
    public class PageBase
    {
        private Logger logger = LogManager.GetCurrentClassLogger();
        private IWebDriver driver=null;

        public PageBase(IWebDriver passed_driver)
        {
            try
            {
                this.driver = passed_driver;
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
        }

        protected Boolean SetInput(IWebElement input, String text)
        {
            logger.Debug("ENTER - input {0}, text ='{1}'", input, text);
            bool result = false;
            try
            {
                IWebElement input1 = driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div/div/div[1]/div[2]/div[3]/input[@type='text']"));
                    //input1.Clear();
                input.SendKeys(text);
                if (GetInput(input1) == text)
                    result = true;
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagonstic Message");
            }
            finally
            {
                logger.Debug("Exit - result = {0}", result);
            }
            return result;
        }

        protected String GetInput(IWebElement input)
        {
            logger.Debug("ENTER - input {0}", input);
            string result = "";

            try
            {
                result = input.GetAttribute("value");
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagonstic Message");
            }
            finally
            {
                logger.Debug("Exit - result = '{0}'", result);
            }
            return result;
        }
        protected Boolean SelectButton(IWebElement button)
        {
            logger.Debug("ENTER - button = {0}", button);
            bool result = false;
            try
            {
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(6);
                //driver.Manage().Timeouts().SeleniumExtras.WaitHelpers.ImplicitWait(TimeSpan.FromSeconds(6));
                    //button.SendKeys(Keys.Enter);
                button.Click();
                result = true;
            }
            catch (Exception ex)
            {
                logger.Debug(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }
        protected Boolean WaitForGridLoad(Int32 sec)
        {
            logger.Debug("ENTER - sec = {0}", sec);
            bool result = false;
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(sec));
                wait.Until<bool>((d) =>
                {
                    try
                    {
                        IWebElement element = d.FindElement(By.ClassName("account-col th"));
                        return false;
                    }
                    catch (NoSuchElementException)
                    {
                        logger.Debug("loading of grid data has completed");
                        result = true;
                        return true;
                    }
                });
            }
            catch (Exception ex)
            {
                logger.Debug(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }
        protected Boolean WaitForElementIsVisiblebyXpath(String xpath, Int32 secs)
        {
            logger.Debug("ENTER - element = {0}, secs={1}", xpath, secs);
            bool result = false;
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(secs));
                //wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(xpath)));
                logger.Debug("Element Found");
                result = true;
            }
            catch (WebDriverTimeoutException ex)
            {
                logger.Debug(ex, "Element not Found");
            }
            catch (Exception ex)
            {
                logger.Debug(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        protected Boolean SelectDropDownOption(IWebElement select, String value)
        {
            logger.Debug("ENTER - link = {0}", select);
            bool result = false;
            try
            {
                ICollection<IWebElement> options = select.FindElements(By.TagName("option"));
                if (options.Count == 1)
                {
                    return (true);
                }
                foreach (IWebElement option in options)
                {
                    if (option.Text == value)
                    {
                        option.Click();
                        //Thread.sleep(160);
                        break;
                    }
                    result = true;
                }
            }
            catch (Exception ex)
            {
                logger.Debug(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        protected Boolean SelectDropDownOption1(IWebElement select, String value1)
        {
            logger.Debug("ENTER - link = {0}", select);
            bool result = false;
            try
            {
                SelectElement TimeZoneSelect = new SelectElement(select);
                IList<IWebElement> ElementCounts = TimeZoneSelect.Options;
                int ItemSize = ElementCounts.Count;

                foreach (IWebElement option in ElementCounts)
                {

                    if (option.Text==value1)
                    {
                        option.Click();
                        Thread.Sleep(200);
                    }
                    result = true;
                }
            }
            catch (Exception ex)
            {
                logger.Debug(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        public bool compareFiles(string filePath1, string filePath2)
        {
            bool result = false;
            Excel.Application excel = new Excel.Application();

            //Open files to compare
            Excel.Workbook workbook1 = excel.Workbooks.Open(filePath1);
            Excel.Workbook workbook2 = excel.Workbooks.Open(filePath2);

            //Open sheets to grab values from
            Excel.Worksheet worksheet1 = (Excel.Worksheet)workbook1.Sheets[1];
            Excel.Worksheet worksheet2 = (Excel.Worksheet)workbook2.Sheets[1];

            //Get the used range of cells
            Excel.Range range = worksheet2.UsedRange;
            int maxColumns = range.Columns.Count;
            int maxRows = range.Rows.Count;

            //Check that each cell matches
            for (int i = 1; i <= maxColumns; i++)
            {
                for (int j = 1; j <= maxRows; j++)
                {
                    if (worksheet1.Cells[j, i].ToString() == worksheet2.Cells[j, i].ToString())
                    {
                        result = true;
                    }
                    else
                        result = false;
                }
            }
            //Close the workbooks
            GC.Collect();
            GC.WaitForPendingFinalizers();
            Marshal.ReleaseComObject(range);
            Marshal.ReleaseComObject(worksheet1);
            Marshal.ReleaseComObject(worksheet2);
            workbook1.Close();
            workbook2.Close();
            excel.Quit();
            Marshal.ReleaseComObject(excel);

            //Tell us if it is true or false
            return result;
        }
        }

}
