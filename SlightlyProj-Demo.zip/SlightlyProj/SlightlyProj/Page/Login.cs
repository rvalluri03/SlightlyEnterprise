﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Data;
using System.Data.SqlClient;
using OpenQA.Selenium.Interactions;
using System.Threading;
using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium.Support.PageObjects;
using SeleniumExtras.PageObjects;
//using FindsByAttribute = OpenQA.Selenium.Support.PageObjects.FindsByAttribute;
//using How = OpenQA.Selenium.Support.PageObjects.How;
using NLog;
using SlightlyProj.PageUtil;

namespace SlightlyProj.Page
{
    public class Login: PageUtil.PageBase
    {
        private Logger logger = LogManager.GetCurrentClassLogger();
        private IWebDriver driver;
        
        public Login(IWebDriver passed_driver)
            : base(passed_driver)
        {
            try
            {
                this.driver = passed_driver;

                if (!driver.Url.Contains("sightly"))
                    throw new NoSuchWindowException("This is not the login page");

                Thread.Sleep(100);
                PageFactory.InitElements(driver, this);
                Thread.Sleep(100);

            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
        }

        #region page elements
        [FindsBy(How = How.XPath, Using = "//input[@type='text']")]
        private IWebElement inputName { get; set;}
        //IWebElement input1 = driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div/div/div[1]/div[2]/div[3]/input[@type='text']"));
        [FindsBy(How = How.XPath, Using = "//input[@type='password']")]
        private IWebElement inputPassword { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@class='login-button']")]
        private IWebElement buttonLogin;

        #endregion

        public Boolean SetLoginName(String name)
        {
            return SetInput(inputName, name);
        }

        public Boolean SetLoginPassword(String password)
        {
            return SetInput(inputPassword, password);
        }

        public Boolean SelectLoginButton()
        {
            return SelectButton(buttonLogin);
        }

        public Boolean LoginSlightly(String name, String password)
        {
            logger.Debug("ENTER - name = {0}, password = {1}", name, password);
            bool result = false;
            bool success = false;
            try
            {
                success = SetLoginName(name);
                if (success == true)
                    Thread.Sleep(100);
                success = SetLoginPassword(password);
                if (success == true)
                    Thread.Sleep(100);
                success = SelectLoginButton();
                Thread.Sleep(200);
                if (success == true)
                    //success = WaitForElementIsVisiblebyXpath("//div[@class='header-content']/h1[contains(@class,'header-title') and contains(text(),'My Assigned Work')]", 6);
                //success = WaitForElementIsVisiblebyXpath("//header/div/span//div/h1[contains(text(),'My Assigned Work'))]", 6);
                if (success == true)
                    //success = WaitForGridLoad(10);
                result = success;

            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }
    }
}
