﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using NLog;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;

namespace SlightlyProj.Driver
{
    public class DriverUtil
    {
        private Logger logger = LogManager.GetCurrentClassLogger();
        private IWebDriver driver;

        public enum WindowSize
        {
            ResolutionMaxmize

        }

        public enum BrowserType
        {
            InternetExplorer,
            Chrome
        }

        public enum TestEnvironment
        {
            QA,
            Stage
        }
        public DriverUtil(BrowserType browser, WindowSize size)
        {
            logger.Debug("ENTER - browser = {0}, size = {1}", browser, size);
            bool result = false;
            try
            {
                //create driver;
                switch (browser)
                {
                    case BrowserType.InternetExplorer:

                        driver = new InternetExplorerDriver();

                        break;
                    case BrowserType.Chrome:
                        
                        driver = new ChromeDriver();
                        break;
                    default:
                        logger.Debug("specified browser type not supported");
                        break;
                }
                //set window size
                SetBrowserWindowSize(size);
                result = true;
            }
            catch (InvalidOperationException e)
            {
                logger.Error(e, "If using Internet Explorer, make sure Protected Mode security settings are the same for all zones");
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }

        }

        public Boolean SetBrowserWindowSize(WindowSize size)
        {
            logger.Debug("ENTER - size = {0}", size);
            bool result = false;
            try
            {
                switch (size)
                {
                    case WindowSize.ResolutionMaxmize:
                        driver.Manage().Window.Maximize();
                        result = true;
                        break;
                    default:
                        logger.Debug("{0} window size is not supported by this method", size);
                        result = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        public IWebDriver GetDriver()
        {
            logger.Debug("ENTER - <no arguments>");
            IWebDriver result = null;
            try
            {
                //driver instantiated upon class initialization
                result = driver;
            }
            catch (Exception ex)
            {
                logger.DebugException("Diagnostic message", ex);
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        public Boolean SetUrl(TestEnvironment envrionment)
        {
            logger.Debug("ENTER - Envrionment = {0}", envrionment);
            bool result = false;
            try
            {
                switch (envrionment)
                {
                    case TestEnvironment.QA:
                        driver.Navigate().GoToUrl("https://staging-newtargetview.sightly.com/");
                        break;
                    case TestEnvironment.Stage:
                        driver.Navigate().GoToUrl("https://staging-newtargetview.sightly.com/");
                        break;
                    default:
                        logger.Debug("{0} Environment is not supported by this method", envrionment);
                        result = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }
        public Boolean RefreshCurrentWindow()
        {
            logger.Debug("ENTER - <no arguments>");
            bool result = false;
            try
            {
                //refresh current window
                driver.Navigate().Refresh();
                result = true;
            }
            catch (Exception ex)
            {
                logger.DebugException("Diagnostic message", ex);
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

    }
}
