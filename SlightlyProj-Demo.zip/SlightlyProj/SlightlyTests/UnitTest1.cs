using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Data;
using System.Data.SqlClient;
using OpenQA.Selenium.Interactions;
using System.Threading;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using SlightlyProj.Page;
using SlightlyProj.Driver;
using System.Collections;
using System.Collections.Generic;

namespace SlightlyTests
{

    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver myDriver;
            SlightlyProj.Driver.DriverUtil myDriverUtil;

            //myDriver = new ChromeDriver();
            //myDriver.Navigate().GoToUrl("https://staging-newtargetview.sightly.com/");

            myDriverUtil = new DriverUtil(DriverUtil.BrowserType.Chrome, DriverUtil.WindowSize.ResolutionMaxmize);
            myDriver = myDriverUtil.GetDriver();
            myDriverUtil.SetUrl(DriverUtil.TestEnvironment.Stage);

            Login logingPage = new Login(myDriver);
            logingPage.LoginSlightly("nick@sightly.com", "a");

            ClickReport clickReportLink = new ClickReport(myDriver);
            clickReportLink.SelectReportImgLink();
            clickReportLink.SelectCheckBox();
            clickReportLink.SelectCreateReport();

            PerformanceDetailReport pdr = new PerformanceDetailReport(myDriver);
            pdr.SelectPeformanceDetailReport();
            pdr.SelectDetailReportInputs("Campaign", "All", "Summary", "None", "All Time");
            pdr.SelectRunReports();
            //myDriver.Quit();
            pdr.CloseReportGenerator();
            Thread.Sleep(100);
            pdr.CloseTargetViewReport();
            //pdr.ValidatePatientTiles();
            //System.Data.DataTable Target = pdr.ReadExcelFile("Target", @"C:\Slightly\SlightlyProj\SlightlyProj\TestData\TargetData.xlsx");
            //System.Data.DataTable Source = pdr.ReadExcelFile("Source", @"C:\Slightly\SlightlyProj\SlightlyProj\TestData\SourceData.xlsx");

            //AreTablesTheSame(Target , Source);

        }

        [TestMethod]
        public void TestMethod2()
        {
            ReportSourceTargetValidation repSTV = new ReportSourceTargetValidation();
            System.Data.DataTable Target = repSTV.ReadExcelFile("Target", @"C:\Slightly\SlightlyProj\SlightlyProj\TestData\PerformanceDetail-Campaign-TargetData.xlsx");
            System.Data.DataTable Source = repSTV.ReadExcelFile("Source", @"C:\Slightly\SlightlyProj\SlightlyProj\TestData\PerformanceDetail-Campaign-SourceData.xlsx");
            var ErrorMessage = repSTV.CompareSourceTarget(Target, Source);

            if (!string.IsNullOrEmpty(ErrorMessage))
            {
                Assert.Fail();
            }

        }

        [TestMethod]
        public void TestMethod3()
        {
            ReportSourceTargetValidation repSTV = new ReportSourceTargetValidation();
            System.Data.DataTable Target = repSTV.ReadExcelFile("Target", @"C:\Slightly\SlightlyProj\SlightlyProj\TestData\PD-Campaign-TargetDataChanges.xlsx");
            System.Data.DataTable Source = repSTV.ReadExcelFile("Source", @"C:\Slightly\SlightlyProj\SlightlyProj\TestData\PD-Campaign-SourceDataChanges.xlsx");
            var ErrorMessage = repSTV.CompareSourceTarget(Target, Source);

            if (!string.IsNullOrEmpty(ErrorMessage))
            {
                Assert.Fail();
            }

        }
    }
}

