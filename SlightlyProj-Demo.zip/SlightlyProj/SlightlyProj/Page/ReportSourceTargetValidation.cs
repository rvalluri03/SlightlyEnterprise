﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.IO;
using System.Collections;
using NLog;

namespace SlightlyProj.Page
{
    public class FailedRow
    {
        public string rowid { get; set; }
        public List<FailedColumn> failedcolumns { get; set; }
    }

    public class FailedColumn
    {
        public string Sourceid { get; set; }
        public string Targetid { get; set; }
    }
    public class ReportSourceTargetValidation
    {
        public System.Data.DataTable ReadExcelFile(string sheetName, string path)
        {

            using (OleDbConnection conn = new OleDbConnection())
            {
                System.Data.DataTable dt = new System.Data.DataTable();
                string Import_FileName = path;
                string fileExtension = Path.GetExtension(Import_FileName);
                if (fileExtension == ".xls")
                    conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Import_FileName + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";
                if (fileExtension == ".xlsx")
                    conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Import_FileName + ";" + "Extended Properties='Excel 12.0 Xml;HDR=YES;'";
                using (OleDbCommand comm = new OleDbCommand())
                {
                    comm.CommandText = "Select * from [" + sheetName + "$]";
                    comm.Connection = conn;
                    using (OleDbDataAdapter da = new OleDbDataAdapter())
                    {
                        da.SelectCommand = comm;
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public string CompareSourceTarget(System.Data.DataTable tbl1, System.Data.DataTable tbl2)
        {
            var failedrows = new List<FailedRow>();

            if (tbl1.Rows.Count != tbl2.Rows.Count || tbl1.Columns.Count != tbl2.Columns.Count)
                Console.WriteLine("Target and source count is not matching");
            //return false;


            for (int i = 0; i < tbl1.Rows.Count; i++)
            {
                var row = new FailedRow();
                row.rowid = i.ToString();
                row.failedcolumns = new List<FailedColumn>();
                for (int c = 0; c < tbl1.Columns.Count; c++)
                {
                    if (!Equals(tbl1.Rows[i][c], tbl2.Rows[i][c]))
                    {

                        //return false;

                        var column = new FailedColumn();
                        column.Targetid = tbl1.Rows[i][c].ToString();
                        column.Sourceid = tbl2.Rows[i][c].ToString();
                        row.failedcolumns.Add(column);
                        failedrows.Add(row);
                        //Assert.Fail("Target Data - " + tbl1.Rows[i][c].ToString() +"  is not matching with source data - " + tbl2.Rows[i][c].ToString());
                    }
                }
            }

            StringBuilder sb = new StringBuilder();

            foreach (var row in failedrows)
            {
                if (row.failedcolumns.Count>0)
                {
                    
                    foreach(var colmn in row.failedcolumns)
                    {
                        sb.Append($"rowid:{row.rowid},Sourceid:{colmn.Sourceid},Targetid:{colmn.Targetid})");
                        //Console.WriteLine(sb.ToString());
                    }
                }
                //string s=  row.rowid;
                //string s1 = row.failedcolumns[0].Sourceid;
                //string s2 = row.failedcolumns[1].Targetid;
                //Console.WriteLine(s1);
                //Console.WriteLine(s2);

            }

            return sb.ToString();

            //return true;
        }
    }
}
