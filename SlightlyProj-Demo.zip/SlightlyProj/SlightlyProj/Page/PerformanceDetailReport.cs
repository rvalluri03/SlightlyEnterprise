﻿using System;
using System.Collections.Generic;
using System.Text;
using NLog;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Linq;
using System.IO;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using OfficeOpenXml.Style;
using System.Data.OleDb;


namespace SlightlyProj.Page
{
    public class PerformanceDetailReport : PageUtil.PageBase
    {
        private Logger logger = LogManager.GetCurrentClassLogger();
        private IWebDriver driver;

        public PerformanceDetailReport(IWebDriver passed_driver)
            : base(passed_driver)
        {
            try
            {
                this.driver = passed_driver;

                //if (!driver.Url.Contains("orders"))
                // throw new NoSuchWindowException("This is not the orders page");

                Thread.Sleep(100);
                PageFactory.InitElements(driver, this);
                Thread.Sleep(100);

            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
        }

        #region page elements
        [FindsBy(How = How.XPath, Using = "//*[@id='header - reports']/div/div[2]/img[1][@src='/rs1/header/regular/reports-icon.svg']")]
        private IWebElement selectRepLink { get; set; }
        //IWebElement input1 = driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div/div/div[1]/div[2]/div[3]/input[@type='text']"));
        [FindsBy(How = How.XPath, Using = "//span[text()='Create Report']")]
        private IWebElement selectSpanCreateReport { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='checkbox' and @class='checkbox-style']")]
        private IWebElement selectCheckbox { get; set; }

        #endregion

        //IWebElement pdrSelection => driver.FindElement(By.Id("performanceDetailReportOption"));

        IWebElement grouping => driver.FindElement(By.XPath("//div/select[@class ='report-dialog-select groupingSelect']"));
        IWebElement costBasis => driver.FindElement(By.XPath("//div/select[@class ='report-dialog-select costBasisSelect']"));
        IWebElement granularity => driver.FindElement(By.XPath("//div/select[@class ='report-dialog-select granularitySelect']"));

        IWebElement addCol => driver.FindElement(By.XPath("//div/select[@class ='report-dialog-select addColSelect']"));

        IWebElement timePeriod => driver.FindElement(By.XPath("//div/select[@class ='report-dialog-select timePeriodSelect']"));

        IWebElement runReports => driver.FindElement(By.XPath("//button[@class='run-report-button']/span/strong[text()='Run Reports']"));
        IWebElement closeRG => driver.FindElement(By.XPath("//div/img[@class='close-icon']"));


        public Boolean SelectReportLink()
        {
            return SelectButton(selectRepLink);
        }

        public Boolean SelectCreateReportbySpan()
        {
            return SelectButton(selectSpanCreateReport);
        }
        public Boolean FindCheckBox()
        {
            return SelectButton(selectCheckbox);
        }

        public Boolean SelectPeformanceDetailReport()
        {
            logger.Debug("ENTER - name = {0}, password = {1}");
            bool result = false;
            bool success = false;
            try
            {

                success = SelectReportLink();
                IList<IWebElement> radioButtons = driver.FindElements(By.XPath("//input[@type ='radio']"));
                // This will tell you the number of checkboxes are present
                int Size = radioButtons.Count;
                // Start the loop from first checkbox to last checkboxe
                for (int i = 0; i < Size; i++)
                {
                    // Store the checkbox name to the string variable, using 'Value' attribute
                    String Value = radioButtons.ElementAt(i).GetAttribute("value");
                    // Select the checkbox it the value of the checkbox is same what you are looking for
                    if (Value.Equals("performanceDetail"))
                    {
                        radioButtons.ElementAt(i).Click();
                        // This will take the execution out of for loop
                        break;
                    }
                }
                Thread.Sleep(100);
                //if (success == true)
                //success = WaitForElementIsVisiblebyXpath("//div[@class='header-content']/h1[contains(@class,'header-title') and contains(text(),'My Assigned Work')]", 6);
                //success = WaitForElementIsVisiblebyXpath("//header/div/span//div/h1[contains(text(),'My Assigned Work'))]", 6);
                if (success == true)
                    success = WaitForGridLoad(10);
                result = success;

            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        public Boolean SelectDetailReportInputs(string groupingSelect, string costBasesSelect, string granularitySelect, string addcolSelect, string timePeriodSelect)
        {
            logger.Debug("ENTER - name = {0}, password = {1}");
            bool result = false;
            bool success = false;
            try
            {
                success = SelectDropDownOption1(grouping, groupingSelect);
                Thread.Sleep(100);
                if (success == true)
                    success = SelectDropDownOption1(costBasis, costBasesSelect);
                Thread.Sleep(100);
                if (success == true)
                    success = SelectDropDownOption1(granularity, granularitySelect);
                Thread.Sleep(100);
                if (success == true)
                    success = SelectDropDownOption1(addCol, addcolSelect);
                Thread.Sleep(100);
                if (success == true)
                    success = SelectDropDownOption1(timePeriod, timePeriodSelect);
                Thread.Sleep(100);
                //success = WaitForGridLoad(10);
                result = success;

            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        public Boolean SelectCreateReport()
        {
            logger.Debug("ENTER - name = {0}, password = {1}");
            bool result = false;
            bool success = false;
            try
            {
                success = SelectCreateReportbySpan();
                Thread.Sleep(100);
                if (success == true)
                    //success = WaitForGridLoad(10);
                    result = success;
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        public Boolean SelectRunReports()
        {
            logger.Debug("ENTER - name = {0}, password = {1}");
            bool result = false;
            bool success = false;
            try
            {
                ((IJavaScriptExecutor)driver).ExecuteScript("document.body.style.zoom='80%'");

                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click()", runReports);

                //success = SelectButton(runReports);
                Thread.Sleep(200);
                if (success == true)
                    //success = WaitForGridLoad(10);
                    result = success;
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Diagnostic Message");
            }
            finally
            {
                logger.Debug("EXIT - result = {0}", result);
            }
            return result;
        }

        public void CloseReportGenerator()
        {
            Thread.Sleep(100);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click()", closeRG);
            Thread.Sleep(100);
        }

        public void CloseTargetViewReport()
        {
            Thread.Sleep(100);
            driver.Close();
            Thread.Sleep(100);
        }
    }
}

